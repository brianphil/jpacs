const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('jpacsdb', 'jpacs', 'test@123', {
  host: 'localhost',
  dialect: 'mysql',
});

module.exports = sequelize;
